package me.whiteship.designpatterns._03_behavioral_patterns._23_visitor._02_after;

public interface Shape {

    void accept(Device device);

}
