package me.whiteship.designpatterns._02_structural_patterns._10_facade._02_after;

public class EmailSettings {

    private String host;

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }
}
