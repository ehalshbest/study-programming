package me.whiteship.designpatterns._03_behavioral_patterns._16_iterator._03_java;

import org.springframework.util.CompositeIterator;

public class IteratorInSpring {

    public static void main(String[] args) {
        CompositeIterator iterator;
    }
}
