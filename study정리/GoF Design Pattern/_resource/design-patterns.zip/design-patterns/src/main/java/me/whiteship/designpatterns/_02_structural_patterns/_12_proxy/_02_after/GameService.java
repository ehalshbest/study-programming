package me.whiteship.designpatterns._02_structural_patterns._12_proxy._02_after;

public interface GameService {

    void startGame();

}
