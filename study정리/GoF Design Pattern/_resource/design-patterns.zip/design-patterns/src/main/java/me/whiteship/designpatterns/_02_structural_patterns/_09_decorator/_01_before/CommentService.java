package me.whiteship.designpatterns._02_structural_patterns._09_decorator._01_before;

public class CommentService {
    public void addComment(String comment) {
        System.out.println(comment);
    }
}
