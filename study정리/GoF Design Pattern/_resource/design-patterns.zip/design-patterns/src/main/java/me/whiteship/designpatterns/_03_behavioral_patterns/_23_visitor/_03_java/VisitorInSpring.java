package me.whiteship.designpatterns._03_behavioral_patterns._23_visitor._03_java;

import org.springframework.beans.factory.config.BeanDefinitionVisitor;

public class VisitorInSpring {

    public static void main(String[] args) {
        BeanDefinitionVisitor beanDefinitionVisitor;
    }
}
