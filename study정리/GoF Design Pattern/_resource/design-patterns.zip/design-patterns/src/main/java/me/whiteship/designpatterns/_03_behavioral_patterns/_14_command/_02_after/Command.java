package me.whiteship.designpatterns._03_behavioral_patterns._14_command._02_after;

public interface Command {

    void execute();

    void undo();

}
