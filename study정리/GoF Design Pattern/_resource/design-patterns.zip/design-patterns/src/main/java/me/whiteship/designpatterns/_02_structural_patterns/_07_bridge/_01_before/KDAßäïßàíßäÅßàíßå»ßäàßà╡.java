package me.whiteship.designpatterns._02_structural_patterns._07_bridge._01_before;

public class KDA아칼리 {
}
