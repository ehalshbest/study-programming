package me.whiteship.designpatterns._03_behavioral_patterns._22_template._03_java;

import javax.servlet.http.HttpServlet;

public class TemplateInJava {

    public static void main(String[] args) {
        HttpServlet httpServlet;
    }
}
