package me.whiteship.designpatterns._02_structural_patterns._08_composite._02_after;

public interface Component {

    int getPrice();

}
