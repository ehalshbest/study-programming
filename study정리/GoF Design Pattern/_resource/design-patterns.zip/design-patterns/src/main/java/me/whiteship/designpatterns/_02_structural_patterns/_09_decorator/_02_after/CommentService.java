package me.whiteship.designpatterns._02_structural_patterns._09_decorator._02_after;

public interface CommentService {

    void addComment(String comment);
}
