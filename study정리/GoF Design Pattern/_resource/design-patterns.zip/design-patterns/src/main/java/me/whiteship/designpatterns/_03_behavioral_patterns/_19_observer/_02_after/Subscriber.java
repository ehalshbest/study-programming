package me.whiteship.designpatterns._03_behavioral_patterns._19_observer._02_after;

public interface Subscriber {

    void handleMessage(String message);
}
