package me.whiteship.designpatterns._02_structural_patterns._07_bridge._02_after;

public class KDA implements Skin{
    @Override
    public String getName() {
        return "KDA";
    }
}
