//라이브러리 및 접근제어(1)
package lib

func CheckNum(c int32) bool {
	return c > 10
}
