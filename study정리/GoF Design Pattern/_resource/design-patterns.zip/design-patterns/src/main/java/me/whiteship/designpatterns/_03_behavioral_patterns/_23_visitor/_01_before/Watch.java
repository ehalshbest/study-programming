package me.whiteship.designpatterns._03_behavioral_patterns._23_visitor._01_before;

public class Watch implements Device{
}
