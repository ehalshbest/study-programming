package me.whiteship.designpatterns._03_behavioral_patterns._17_mediator._03_java;

import org.springframework.web.servlet.DispatcherServlet;

public class MediatorInSpring {

    public static void main(String[] args) {
        DispatcherServlet dispatcherServlet;
    }
}
