package me.whiteship.designpatterns._03_behavioral_patterns._17_mediator._02_after;

import java.time.LocalDateTime;

public class Restaurant {
    public void dinner(Integer id, LocalDateTime dateTime) {

    }
}
