//라이브러리 및 접근제어(2)
package lib

func CheckNum1(c int32) bool {
	return c > 100
}

func checkNum2(c int32) bool {
	return c > 1000
}
